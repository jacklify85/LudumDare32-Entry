echo Starting Super ZDefeat by jacklify85
java -jar SuperZDefeat.jar